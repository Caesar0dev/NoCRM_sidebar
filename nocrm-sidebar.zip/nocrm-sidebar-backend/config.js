"use strict";

const CONSTANT = {
  PRINT_LOG: 1,
  PRINT_WARN: 2,
  PRINT_ERROR: 4,
  PRINT_ALL: 7,
  PRINT_NONE: 0,
};
exports.CONSTANT = CONSTANT;
exports.CONFIG = {
  VERSION: "0.1.9",
  HOST: "0.0.0.0",
  PORT: 8080,
  PRINT: CONSTANT.PRINT_ALL,
  STRIPE: {
    KEY: "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",
  }
};
