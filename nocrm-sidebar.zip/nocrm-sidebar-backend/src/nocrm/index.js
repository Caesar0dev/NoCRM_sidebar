"use strict";
// const NoCRM = require("../nocrm");
const axios = require('axios');

const request = require("../request");
const Utils = require("../utils");
const URL = {
  PERSON_FIELDS: "https://api.pipedrive.com/v1/personFields?api_token=",
  PERSONS: "https://api.pipedrive.com/api/v1/persons/",
  ME: "https://api.pipedrive.com/v1/users/me?api_token=",
  LOGIN: "https://nocrm.io/api/v2/auth/login",
};

/**
 * Class for all api of pipedrive
 */
class NoCRM {
  /**
   * Get my information
   * @param {string} token api token
   * @return my customer information
   */
  static getMyInfo(me) {
    return new Promise(async (resolve, reject) => {
      const tokenHeader = [["X-USER-TOKEN", me.token]];
      request(
        "https://" + me.slug + ".nocrm.io/api/v2/users/" + me.user_id,
        "GET",
        {},
        tokenHeader
      )
        .then((r) => {
          resolve(r);
        })
        .catch((r) => reject(r));
    });
  }
  /**
   *
   * @param {number} id
   * @param {string} field
   * @param {string} text
   */

  static login(email, password) {
    return new Promise(async (resolve, reject) => {
      const authHeader = Utils.auth.authenticateUser(email, password);

      request(URL.LOGIN, "GET", {}, authHeader)
        .then((r) => {
          resolve(r);
        })
        .catch((r) => {
          console.log("failed", r);
          reject(r);
        });
    });
  }
  ////////////////////   first  ////////////////////////
  static getComingDeals(data, me) {
    return new Promise(async (resolve, reject) => {
      const tokenHeader = [["X-USER-TOKEN", data.token]];
      console.log("----index.js/data------", data);
      console.log("----index.js/me------", me);
      request(
        "https://" +
        data.slug +
        ".nocrm.io/api/v2/leads?status=standby&order=next_action&direction=asc&user_id=" +
        me.id,
        "GET",
        {},
        tokenHeader
      )
        .then((r) => {
          ////////////////////////////////
          let payload = { 'action': "Login", 'first_name': me.firstname, 'last_name': me.lastname, 'email_id': me.email };
          let res = axios.post('https://connect.pabbly.com/workflow/sendwebhookdata/IjU3NjEwNTY4MDYzNjA0Mzc1MjZmNTUzNSI_3D_pc', payload)
            .then(function (response) {
              console.log("---------user is logged in now.-------", response);
            });
          let data = res.data;
          ////////////////////////////////
          resolve(r);

        })
        .catch((r) => reject(r));

    });
  }
  static getNextDeals(data, me) {
    return new Promise(async (resolve, reject) => {
      const tokenHeader = [["X-USER-TOKEN", data.token]];

      request(
        "https://" +
        data.slug +
        ".nocrm.io/api/v2/leads?status=todo&order=next_action&direction=asc&user_id=" +
        me.id,
        "GET",
        {},
        tokenHeader
      )
        .then((r) => {
          resolve(r);
        })
        .catch((r) => reject(r));
    });
  }
  ///////////////////////////////////////////////////
  static getCreateLead(data) {
    return new Promise(async (resolve, reject) => {
      console.log(">>>>========noCRM/index.js/getCreateLead=======>>>>", data);
      const tokenHeader = [["X-USER-TOKEN", data.token]];
      console.log(">>>>========noCRM/index.js/tokenHeader=======>>>>", tokenHeader);
      request(
        "https://" + data.slug + ".nocrm.io/api/v2/leads/",
        "POST",
        { title: data.title, description: data.description},
        tokenHeader
      )
        .then((r) => {
          console.log(">>>===========r==========>>>", r);
          resolve(r);
        })
          .catch((r) => {
            console.log("==========createlead=failed=======>>>>>", r);
            reject(r)
          });
        // request(
        //   "https://www.nocrm.io/api/v2/leads/",
        //   "POST",
        //   {
        //     title: data.title,
        //     Firstname: "Kurt",
        //     Lastname: "Jone",
        //     Phone: "123456789",
        //     Email: "kurt@jones.net.au",
        //     amount: data.amount,
        //   },
        //   tokenHeader
        // )
        //   .then((r) => {
        //     console.log(">>>>>>=====  create lead result  =====>>>>>>", resolve(r));
        //   })
        //   .catch((r) => {
        //     console.log("==========createlead=failed=======>>>>>", r);
        //     reject(r)
        //   });
    });
  }
  //////////////////////////////////////////////////
  ///////////////   second     /////////////////////
  static getMyDeals(data, me) {
    console.log(">>>>>>>>>>=======getMyDeals(data)========>>>>>>>>", data);
    console.log(">>>>>>>>>>=======getMyDeals(me)========>>>>>>>>", me);
    return new Promise(async (resolve, reject) => {
      const tokenHeader = [["X-USER-TOKEN", data.token]];
      console.log(
        data.id
          ? "https://" +
          data.slug +
          ".nocrm.io/api/v2/leads?email=" +
          data.email +
          "&user_id=" +
          data.id
          : "https://" + data.slug + ".nocrm.io/api/v2/leads"
      );

      if (data.id) {
        console.log("========1=================>");
        request(
          "https://" +
          data.slug +
          ".nocrm.io/api/v2/leads?email=" +
          data.email +
          "&user_id=" +
          data.id,
          "GET",
          {},
          tokenHeader
        )
          .then((r) => {
            console.log("========2=================>", r);
            ////////////////////////////////
            let payload = { 'action': "inbox_view", 'first_name': JSON.parse(me).firstname, 'last_name': JSON.parse(me).lastname, 'email_id': JSON.parse(me).email };
            let res = axios.post('https://connect.pabbly.com/workflow/sendwebhookdata/IjU3NjEwNTY4MDYzNjA0Mzc1MjZmNTUzNSI_3D_pc', payload)
              .then(function (response) {
                console.log("---------user is visiting the email now.-------", response);
              });
            let data = res.data;
            //////////////////////////
            resolve(r);
          })
          .catch((r) => {
            console.log("========3=================>", r);
            reject(r)
          });
      } else {
        console.log("========4=================>");
        request(
          "https://" + data.slug + ".nocrm.io/api/v2/leads",
          "GET",
          {},
          tokenHeader
        )
          .then((r) => {
            console.log("========5=================>", r);
            //////////////////////////////
            let payload = { 'action': "deals", 'first_name': me.firstname, 'last_name': me.lastname, 'email_id': me.email };
            let res = axios.post('https://connect.pabbly.com/workflow/sendwebhookdata/IjU3NjEwNTY4MDYzNjA0Mzc1MjZmNTUzNSI_3D_pc', payload)
              .then(function (response) {
                console.log("---------user is visiting the email error.-------", response);
              });
            let data = res.data;
            ////////////////////////
            resolve(r);
            
          })
          .catch((r) => {
            console.log("========6=================>", r);
            reject(r);
          });
      }

    });
  }
  static getAllUsers(data) {
    return new Promise(async (resolve, reject) => {
      const tokenHeader = [["X-USER-TOKEN", data.token]];
      request(
        "https://" + data.slug + ".nocrm.io/api/v2/users/?status=activated",
        "GET",
        {},
        tokenHeader
      )
        .then((r) => {
          resolve(r);
        })
        .catch((r) => reject(r));
    });
  }
  static logout(data) {
    return new Promise(async (resolve, reject) => {
      const authHeader = [["X-USER-TOKEN", data.token]];

      request(
        "https://" + data.slug + ".nocrm.io/api/v2/auth/logout",
        "GET",
        {},
        authHeader
      )
        .then((r) => {
          resolve(r);
        })
        .catch((r) => {
          console.log("failed", r);
          reject(r);
        });
    });
  }
  static updatePerson(id, token, field, fieldValue) {
    return new Promise(async (resolve, reject) => {
      const data = {};
      data[field] = fieldValue;
      request(URL.PERSONS + id + "?api_token=" + token, "PUT", data)
        .then((r) => {
          resolve(r.data);
        })
        .catch((r) => reject(r));
    });
  }

  static updateEmail(id, token, isAppend, emails) {
    return new Promise(async (resolve, reject) => {
      const address = [];
      for (const mail of emails) {
        // zerobounce return invalid add "invalid" to email address.
        console.log("updating email", mail);
        const email = {};
        let mail_value = "";
        let value = mail.email.value;
        if (value.indexOf("(") > 0)
          mail_value = value.substr(0, value.indexOf("("));
        else mail_value = value;
        console.log("mail_value dat", mail.status["status"]);

        if (mail.status["status"] == "invalid") {
          if (!isAppend) email["value"] = "";
          else email["value"] = mail_value + "(" + mail.status["status"] + ")";
        } else email["value"] = mail_value;
        email["label"] = mail.email.label;
        email["color"] = "red";
        address.push(email);
      }

      const headers = [
        ["Content-Type", "application/json"],
        ["Accept", "application/json"],
      ];

      request(
        URL.PERSONS + id + "?api_token=" + token,
        "PUT",
        { email: address },
        headers
      )
        .then((r) => {
          resolve(r.data);
        })
        .catch((r) => reject(r));
    });
  }
  static getPersonById(id, token) {
    return new Promise(async (resolve, reject) => {
      request(URL.PERSONS + id + "?api_token=" + token)
        .then((r) => {
          resolve(r.data);
        })
        .catch((r) => reject(r));
    });
  }

  /**
   * @summary get filed of person
   * @param {string} token
   */
  static personField(token) {
    return new Promise(async (resolve, reject) => {
      try {
        function search(fields) {
          try {
            if (fields) {
              for (const field of fields) {
                console.log("field name", field);
                if (field.name == "Email Validation") return field;
              }
            }
          } catch (e) {
            Utils.print.error("Error in PipeDrive:personFiled.", e);
          }
          return null;
        }

        // try to request with "GET" method
        // const retGet = request(URL.PERSON_FIELDS + token)
        // .then((r) => {
        //     resolve(r.data);
        // })
        // .catch((r) => reject(r));

        const retGet = await request(URL.PERSON_FIELDS + token);
        console.log("person custom filters", retGet);
        const evField = search(retGet.data);
        if (!evField) {
          //try to request with "POST"
          const retPost = request(URL.PERSON_FIELDS + token, "POST", {
            name: "Email Validation",
            field_type: "text",
          });
          resolve(retPost.data);
          console.log("no exist.", retPost.data);
        } else {
          console.log("exist", evField);
          resolve(evField);
        }
      } catch (e) {
        reject(e);
      }
    });
  }
}
module.exports = NoCRM;
