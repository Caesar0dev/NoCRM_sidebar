"use strict";

const Print = require("./log");

class Socket {
  static sendData(socket, type, data) {
    Print.log(`Send to ${socket._socket.remoteAddress}`, { type, data });
    socket.send(JSON.stringify({ type, data }));
  }
  static sendError(socket, message) {
    Print.log(`Send to ${socket._socket.remoteAddress}`, {
      type: "error requeset",
      data: {
        email: socket.user_email,
        messages: message,
        errorMessage: message,
      },
    });
    socket.send(
      JSON.stringify({
        type: "error request",
        data: {
          email: socket.user_email,
          messages: message,
          errorMessage: message,
        },
      })
    );
  }
}
module.exports = Socket;