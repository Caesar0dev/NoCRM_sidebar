"use strict";

const CONFIG = require("../../config").CONFIG;
const CONSTANT = require("../../config").CONSTANT;
class Auth {
  // Custom log print function
  static authenticateUser(user, password) {
    var token = user + ":" + password;

    var hash = Buffer.from(token).toString("base64");
    console.log("base64", hash);
    return [["Authorization", "Basic " + hash]];
  }
  static log(e1, e2) {
    if (CONFIG.PRINT & CONSTANT.PRINT_LOG)
      console.log(new Date().toISOString() + "\tLog: ", e1, e2);
  }
  static warn(e1, e2) {
    if (CONFIG.PRINT & CONSTANT.PRINT_WARN)
      console.warn(new Date().toISOString() + "\tWarning: ", e1, e2);
  }
}

module.exports = Auth;
