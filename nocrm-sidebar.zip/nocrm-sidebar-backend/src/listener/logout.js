"use strict";

const Utils = require("../utils");
const NoCRM = require("../nocrm");
/**
 * @summary                 Event Listener for 'introduce' message. At this time api_token is set and will be used for almost listener.
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
module.exports = async function (socket, message) {
  console.log("message data", message.data);
  NoCRM.logout(message.data)
    .then(async (me) => {
      // api_token session variables for user.
      try {
        console.log("success request", me);
      } catch (e) {
        Utils.print.error("Failed in Login. ", e);
      }
    })
    .catch((err) => {
      Utils.socket.sendError(socket, err);
    });
};