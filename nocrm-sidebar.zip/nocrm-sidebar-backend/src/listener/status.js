"use strict";

/**
 * @summary                 Event Listener for 'introduce' message. At this time api_token is set and will be used for almost listener.
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
const Utils = require("../utils");
const NoCRM = require("../nocrm");
const deals = require("./deals");
module.exports = async function (socket, message) {
  // api_token session variables for user.
  console.log("---status.js/message data sutatus--->", message);
  NoCRM.getMyInfo(message.data)
    .then(async (me) => {
      try {
        const users = await NoCRM.getAllUsers(message.data, JSON.parse(me));
        const nextdeals = await NoCRM.getNextDeals(message.data, JSON.parse(me));
        const comingdeals = await NoCRM.getComingDeals(message.data, JSON.parse(me));
        let names = {};
        users.length > 0
          ? JSON.parse(users).forEach((user) => {
            let name =
              (user.firstname ? user.firstname : "") +
              (user.lastname ? " " + user.lastname : "");
            names[user.id] = name;
          })
          : "";
        sendStatus(socket, me, users, names, nextdeals, comingdeals);
      } catch (e) {
        Utils.print.error("Failed in Introduction. ", e);
      }
    })
    .catch((err) => {
      Utils.socket.sendError("In status", err);
    });
};

function sendStatus(socket, me, users, names, nextdeals, comingdeals) {
  Utils.socket.sendData(socket, "status", {
    user: JSON.parse(me),
    names: names,
    user: JSON.parse(users),
    nextdeals: JSON.parse(nextdeals),
    comingdeals: JSON.parse(comingdeals),
  });
}
