"use strict";

const Utils = require("../utils");
const NoCRM = require("../nocrm");
const axios = require('axios');

/**
 * @summary                 Event Listener for 'introduce' message. At this time api_token is set and will be used for almost listener.
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
module.exports = async function (socket, message) {
  socket.SESSION_VARS["api_token"] = message.data.token;

  NoCRM.login(message.data.email, message.data.password)
    .then(async (me) => {
      // api_token session variables for user.

      try {
        ////////////////////recieve login info and send user data//////////////////////////////
        const meObj = JSON.parse(me)
        console.log("=======>", meObj.slug);

        let fields = await axios.get(`https://${meObj.slug}.nocrm.io/api/v2/fields?type=lead`, { headers: { 'X-USER-TOKEN': meObj.token } });
        let steps = await axios.get(`https://${meObj.slug}.nocrm.io/api/v2/steps`, { headers: { 'X-USER-TOKEN': meObj.token } });

        const resData = {
          auth: meObj,
          fields: fields.data,
          steps: steps.data
        }
        console.log("==========login.js/resData============s====>", resData);

        ////////////////////////////////////////////////////////////
        sendStatus(socket, resData);

        //////////////////////////////////////////////////////

        // fetch('https://certa-dev.nocrm.io/api/v2/fields?type=lead', { headers: { 'X-USER-TOKEN': 'aTW9E7y-cNRMv9XuNy4ViA'} })
        //     .then(response => response.text())
        //     .then(response => chrome.storage.local.set({ fields: response }))
        ///////////////////////////////////

        // try to retrieve Customer object for me.
        const user = await NoCRM.getMyInfo(JSON.parse(me));
        const parseUser = JSON.parse(user);

        const payload = { 'first_name': parseUser.firstname, 'last_name': parseUser.lastname, 'email_id': parseUser.email };

        let res = await axios.post('https://payments.pabbly.com/api/v1/customer', payload, {
          auth: {
            username: '5fc05bbdc9bf3688764a',
            password: '8ceb4bdb764e6755e630a50ba3b05abb'
          }
        });

        // const comingdeals = await NoCRM.getComingDeals(message.data, parseUser);//////////////    for testing    ///////////////////

        ///////////////////////**************//////////////////////////////////
        async function doPostRequest() {
          let payload = { 'action': "Login", 'first_name': parseUser.firstname, 'last_name': parseUser.lastname, 'email_id': parseUser.email };
          let res = await axios.post('https://connect.pabbly.com/workflow/sendwebhookdata/IjU3NjEwNTY4MDYzNjA0Mzc1MjZmNTUzNSI_3D_pc', payload);
          let data = res.data;
          console.log("-----login.js/data----", data);
        }
        doPostRequest();
        ///////////////////////**************///////////////////////////////////
        let data = res.data;
        console.log('====login.js/data====>', data);

      } catch (e) {
        Utils.print.error("Failed in Login. ", e);
      }
    })
    .catch((err) => {
      // Utils.socket.sendError(socket, err);
      Utils.socket.sendData(socket, "loginFail", {
        message: err,
      });
    });
};

function sendStatus(socket, data) {
  Utils.socket.sendData(socket, "loggedin", data);
}
