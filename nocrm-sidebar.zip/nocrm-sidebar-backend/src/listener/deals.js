"use strict";

/**
 * @summary                 Event Listener for 'introduce' message. At this time api_token is set and will be used for almost listener.
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
const Utils = require("../utils");
const NoCRM = require("../nocrm");
module.exports = async function (socket, message) {
  // api_token session variables for user.
  console.log("----deals.js/message data deals---->", message);

  NoCRM.getMyInfo({ slug: message.data.slug, user_id: message.data.id, token: message.data.token })
    .then(async (me) => {
      console.log(">>>>>----deals.js/me---->>>>>", me);
      NoCRM.getMyDeals(message.data, me)
        .then(async (deals) => {
          console.log(">>>>>----deals.js/message.data---->>>>>", message.data);
          console.log(">>>>>----deals.js/JSON.parse(me)---->>>>>", JSON.parse(me));
          try {
            sendStatus(socket, deals);
            console.log(">>>>>----deals.js/sendStatus.deals---->>>>>", deals);
          } catch (e) {
            Utils.print.error("Failed in Introduction. ", e);
          }
        })
        .catch((err) => {
          Utils.socket.sendError("In status", err);
        });
    })
    .catch((err) => {
      console.log(">>>>>----deals.js/err---->>>>>", err);
      Utils.socket.sendError("In status", err);
    });
  /////////////////////////////////////////////////////////
  // NoCRM.getMyDeals(message.data)
  //   .then(async (deals) => {
  //     try {
  //       sendStatus(socket, deals);
  //     } catch (e) {
  //       Utils.print.error("Failed in Introduction. ", e);
  //     }
  //   })
  //   .catch((err) => {
  //     Utils.socket.sendError("In status", err);
  //   });
  //////////////////////////////////////////////////////////
};

function sendStatus(socket, deals) {
  Utils.socket.sendData(socket, "deals", {
    deals: JSON.parse(deals),
  });
}
