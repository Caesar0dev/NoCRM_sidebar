"use strict";

/**
 * @summary                 Event Listener for 'introduce' message. At this time api_token is set and will be used for almost listener.
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
const Utils = require("../utils");
const NoCRM = require("../nocrm");
module.exports = async function (socket, message) {
  // api_token session variables for user.
  console.log("message data lead->", message);
  NoCRM.getCreateLead(message.data)
    .then(async (deals) => {
      try {
        console.log(">========lead=========>", deals);
        sendStatus(socket, deals);
      } catch (e) {
        Utils.print.error("Failed in Introduction. ", e);
      }
    })
    .catch((err) => {
      Utils.socket.sendError("In status", err);
    });
};

function sendStatus(socket, deals) {
  Utils.socket.sendData(socket, "createlead", {
    createlead: JSON.parse(deals),
  });
}
