"use strict";

module.exports = {
  login: require("./login"),
  status: require("./status"),
  deals: require("./deals"),
  createlead: require("./createlead"),
  nextdeals: require("./nextdeals"),
  logout: require("./logout"),
};

// module.exports = {
//     status: require('./status'),
//     payment: require('./payment'),
//     paymentSuccess: require('./paymentSuccess'),
//     getFile: require('./getFile'),
//     validate: require('./validate'),
//     updateEmail: require('./updateEmail'),
//     validateEmail: require('./validateEmail'),
//     oauth: require('./oauth')
// };
